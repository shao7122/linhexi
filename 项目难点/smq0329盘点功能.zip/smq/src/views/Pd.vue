<template>
    <div>
        <div> 盘点</div>
        <div>  
            <button @click="printOut"> 导出 </button>
            <el-table :data="list" >
                <el-table-column  prop="id" label="id"></el-table-column>
                <el-table-column  prop="goodname" label="名称"></el-table-column>
                <el-table-column prop="no" label="编号" />
                <el-table-column  label="盘点状态" >
                    <template #default="{row}">
                           <span v-if="row.isCheck">存在</span>
                           <span v-else>问一下伊南</span>
                    </template>    
                </el-table-column>
            </el-table>
        </div>
    </div>
</template>
<script setup>
 import { ref ,onMounted} from 'vue'
 import { utils ,writeFile,writeFileXLSX} from 'xlsx';

 const list = ref([
    {id:1,goodname:'电脑',no: 10001},
    {id:2,goodname:'手机', no:10002},
    {id:3,goodname:'麦克风', no:10003},
    { id:4,goodname:'灭火器',no:10004 }
 ])

 const code = ref('');
 const arr = ref([]);
 const timer = ref(null);
 const stime = ref('')
 const exitsArr = ref([])

 const check = ()=>{
    console.log('检测是否在待盘点列表中')
    list.value = list.value.map(item=>{
        return {
            ...item,
            isCheck: exitsArr.value.includes(item.no+'')
        }
    } )
 }

 // excel表格的导出
 const printOut = ()=>{
          // 把数据添加到 sheet对象当中

          let sheet1data =  list.value.map(item=>{
            return {
                id: item.id,
                商品名称: item.goodname,
                是否在库: item.isCheck ? '在':'不在'
            }
          });

          // 把数据写入到sheet当中
          const sheet1 = utils.json_to_sheet(sheet1data);

           // 新建一个 工作簿
           const wb = utils.book_new();

          // 在wordkbook当中追加sheet
          utils.book_append_sheet(wb, sheet1 ,'盘点信息')

          //以上的流程只是完成了 excel文件的对象的构造。我们还需要想办法把它下载下来
           writeFileXLSX(wb,`盘点文件${Date.now()}.xlsx`)
 }
 onMounted(()=>{
    window.addEventListener('keypress',(ev)=>{
            if(timer.value) clearTimeout(timer.value);
            const {  key } = ev;
            if(key==='Enter'){
                // 还是计算这一次录入的平均间隔时间
                const totalTime =  Date.now() - stime.value;
                const avaTime = totalTime / arr.value.length;
                console.log('平均输入时间', avaTime);
                if(avaTime < 10){
                console.log('扫码枪输入', arr.value.join(""));
                    code.value = arr.value.join("");
                    exitsArr.value.push(arr.value.join(""))
                // this.showGood = true; // 显示弹窗
                // this.getGoodInfo(); // 获取商品信息
                check();
                 arr.value = []
                } else {
                console.log('不是扫码枪输入');
                 arr.value = []
                }
            } else {
                if(arr.value.length === 0){
                    stime.value =  Date.now()
                }
                arr.value.push(key);
                timer.value = setTimeout(()=>{
                    arr.value = []
                },50)
            }
                
            })
 })
     
</script>