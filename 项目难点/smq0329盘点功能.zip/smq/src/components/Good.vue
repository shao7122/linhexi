<template>
    <el-dialog v-model="showGood">
        <div>
            <div>我是一个弹窗组件</div>
            <div> 商品编码: <el-input v-model="code" /> </div>
            <el-form>
                <el-form-item label="商品名称">
                    <el-input v-model="goodInfo.goodsName" />
                </el-form-item>
                <el-form-item label="品牌">
                    <el-input v-model="goodInfo.trademark" />
                </el-form-item>
                <el-form-item label="规格">
                    <el-input v-model="goodInfo.spec" />
                </el-form-item>
                <el-form-item label="数量">
                    <el-input v-model.number="goodInfo.nums" />
                </el-form-item>
            </el-form>
        </div>
        <template #footer>
            <el-button>确认入库</el-button>
        </template>
       
    </el-dialog>
</template>
<script>
import axios from 'axios';
    export default {
        data(){
            return {
                showGood: false,
                code:'',
                arr:[],
                timer: null,
                goodInfo:{}
            }
        },
        mounted(){

            window.addEventListener('keypress',(ev)=>{
            if(this.timer) clearTimeout(this.timer);
            
            const {  key } = ev;
            if(key==='Enter'){
                // 还是计算这一次录入的平均间隔时间
                const totalTime =  Date.now() - this.stime;
                const avaTime = totalTime / this.arr.length;
                console.log('平均输入时间', avaTime);
                if(avaTime < 10){
                console.log('扫码枪输入', this.arr.join(""));
                this.code = this.arr.join("");
                this.showGood = true; // 显示弹窗
                this.getGoodInfo(); // 获取商品信息
                this.arr = []
                } else {
                console.log('不是扫码枪输入');
                this.arr = []
                }
            } else {
                if(this.arr.length === 0){
                    this.stime =  Date.now()
                }
                this.arr.push(key);
                this.timer = setTimeout(()=>{
                this.arr = []
                },50)
            }
                
            })
        },
        methods:{
            async getGoodInfo(){
                const res = await  axios.get(`http://ali-barcode.showapi.com/barcode?code=${this.code}`,{
                    headers:{
                        Authorization:"APPCODE 092a111065d6469982db25134a0520f7"
                    }
                });
                console.log('res',res)
                this.goodInfo = res.data.showapi_res_body

            }
        }

    }
</script>