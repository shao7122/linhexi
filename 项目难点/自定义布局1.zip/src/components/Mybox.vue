<template>
  <div
    class="mybox"
    :style="{
      width: cpprops.width.value + 'px',
      height: cpprops.height.value + 'px',
      borderColor: cpprops.bdcolor.value,
      borderWidth: cpprops.bdwidth.value + 'px',
      borderStyle: bdStyle,
    }"
  >
    {{ cpprops }}
  </div>
</template>
<script lang="ts">
import { defineComponent } from 'vue';

export default defineComponent({
  props: {
    cpprops: {
      default() {
        return {
          width: {
            value: 0,
          },
          height: {
            value: 0,
          },
          bdcolor: {
            value: '',
          },
          bdwidth: {
            value: '',
          },
        };
      },
    },
  },
});
</script>
