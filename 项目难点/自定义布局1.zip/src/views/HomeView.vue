<template>
  <div class="home">
    <div class="l">
      <div>物料区</div>
    </div>
    <div class="ct">
      <div class="preview">
        <!-- 展示一个div -->

        <Mybox :cpprops="mycp.props" />
        <component
          :is="'Mybox'"
          :width="width"
          :height="height"
          :bdColor="bdColor"
          :bdStyle="bdStyle"
          :bdWidth="bdWidth"
        />

        <!-- 展示一个第三方组件 -->

        <el-carousel height="150px">
          <el-carousel-item v-for="item in imgs.filter((it) => it)" :key="item">
            <img :src="item" alt="img" />
          </el-carousel-item>
        </el-carousel>
      </div>
    </div>
    <div class="r">
      <div>属性配置区域</div>

      <div v-for="(value, key) of mycp.props" :key="value">
        {{ key }} :
        <!--  根据type的值来渲染出不同的 组件 -->
        <template v-if="value.type === 'input'">
          <input :placeholder="value.placeholder" v-model="value.value" />
        </template>
        <!-- 如果是颜色选择器 -->
        <template v-if="value.type === 'color'">
          <el-color-picker v-model="value.value" />
        </template>
        <!-- 如果是 slider -->
        <template v-if="value.type === 'slide'">
          <el-slider v-model="value.value" />
        </template>
      </div>

      <hr />
      <!-- <button @click="imgs.push('')">添加一个图片</button>

      <el-upload
        v-model:file-list="fileList"
        class="upload-demo"
        action="http://www.wzsqyg.com/attachment/upload"
        multiple
        name="file"
        :limit="5"
        :on-success="handleSuccess"
      >
        <el-button type="primary">Click to upload</el-button>
        <template #tip>
          <div class="el-upload__tip">jpg/png files with a size less than 500KB.</div>
        </template>
      </el-upload>

      <div v-for="(item, index) of imgs" :key="index">
        <input placeholder="请输入图片的链接地址" v-model="imgs[index]" />
        <span @click="imgs.splice(index, 1)">删除</span>
      </div> -->
    </div>
  </div>
</template>

<script lang="ts">
import { defineComponent } from 'vue';
import Mybox from '@/components/Mybox.vue';

const mycp = {
  name: 'Mybox',
  props: {
    width: {
      type: 'input',
      placeholder: '请输入宽度',
      value: '',
    },
    height: {
      type: 'input',
      placeholder: '请输入高度',
      value: '',
    },
    bdcolor: {
      type: 'color',
      value: '',
    },
    bdwidth: {
      type: 'slide',
      valeu: '',
    },
  },
};

const myLb = {
  name: 'el-carousel',
};

export default defineComponent({
  name: 'HomeView',
  components: {
    Mybox,
  },
  data() {
    return {
      width: '',
      height: '',
      bdStyle: '',
      bdWidth: '',
      bdColor: '',
      imgs: [],
      fileList: [],
      mycp,
    };
  },
  methods: {
    handleSuccess(res: any) {
      console.log('上传成功', res);
      this.imgs.push(res.msg);
    },
  },
});
</script>
<style scoped lang="scss">
.home {
  width: 100vw;
  height: 100vh;
  display: flex;
}
.l {
  width: 350px;
  border-right: 1px solid #000;
}
.r {
  width: 350px;
  border-left: 1px solid #000;
}
.ct {
  width: 0;
  flex-grow: 1;
  display: flex;
  background: #ccc;
  justify-content: center;
  align-items: center;
}
.preview {
  width: 500px;
  height: 80%;
  background: #fff;
}
.mybox {
  border: 1px solid #000;
}
.small {
  height: 200px;
}
</style>
