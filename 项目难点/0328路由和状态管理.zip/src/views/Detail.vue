<template>
    <div>
        详情页
        <button @click="goPre">上一篇</button>
        <button @click="goNext">下一篇</button>
    </div>
</template>
<script>
export default {
    mounted(){
        console.log('$route in detail',this.$route)
        document.title = this.$route.meta.title
    },
    watch:{
        '$route'(nv,ov){
            console.log('利用 监听器也可以实现 对路由参数变化成监听')
        }
    },  
    created(){
        console.log('创建完成 去获取详情信息')
    },
    methods:{
        goPre(){
            const { abc } = this.$route.params;
            const id = Number(abc) -1;
            this.$router.push('/detail/'+id)
        },
        goNext(){
            const { abc } = this.$route.params;
            const id = Number(abc) +1;
            this.$router.push('/detail/'+id)
        }
    },
    beforeRouteEnter(to,from){
        console.log('路由进入之前')
        //  可以在这里进行一些权限的判断 符合条件的可以进入
        if(from.path === '/'){
            return true
        }
        return false

    },
    beforeRouteUpdate(){
        // 在路由不变 只是参数发生变化的时候组件不会销毁 所以我们没有办法在创建过程当前重新请求详情数据
        // 所以我们可以利用  beforeRouteUpdate 来监听路由参数的变化
        console.log('beforeRouteUpdate 执行')
        return true
    }
}
</script>