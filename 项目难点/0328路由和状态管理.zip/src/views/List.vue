<template>
    <div> 
        我是列表页
        
            <router-link to="/detail/6666">跳转到详情页</router-link>
   </div>
</template>
<script>
export default {
    mounted(){
        console.log('route in list', this.$route)
    }
}
</script>