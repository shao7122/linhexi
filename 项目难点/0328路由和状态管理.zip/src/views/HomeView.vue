<template>
  <div class="home">
    {{  $store.state  }}
    <div> getter :  {{ $store.getters.dbTotal }} </div>
    <button @click="fn1"> 修改total的值 </button>
    <button @click="fn2"> 调用actions对象 </button>
    <button @click="fn3">触发store当中的fncom</button>
    <button @click="fn4"> 触发order模块的fncom</button>
    <button @click="fncom"> 触发fncom</button>


    <hr />
    {{ $store.state.total }} {{ total }}
    <hr />
    <h1> 路由</h1>
    <router-link to="/about"> 跳转到 about</router-link>
    <button @click="gotoAbout"> 跳转到about </button>
    <button @click="gotoDetail"> 跳转到详情页 </button>
</div>
</template>

<script>

// 辅助函数
import { mapState,mapMutations } from 'vuex'
export default {
  name: 'HomeView',
  methods:{
    gotoAbout(){
      // this.$router.push('/about?id=123')
      // this.$router.push({path:'/about',query:{ id:123,a:456 }})
      this.$router.push({ name: 'about',query:{ id:888,a:555}})
    },
    gotoDetail(){
      // this.$router.push({ name: 'detail', params:{ abc:2222 } })
      this.$router.push('/detail/9999')
    },
    fn1(){
      // 在配置api当中 使用 this.$store来得到store实例
      /*
          this.$store.commit(
              mutations当中的函数名称, 
              传递的参数 
          )
       */  
      // 约定 只能通过 执行mutaions的函数来修改状态
      this.$store.commit('setTotal', 1)
       // 实际上是可以直接修改的 但是vue devtool 无发追踪和复现变化的过程
      // this.$store.state.total++
    },
    fn2(){
      // 约定 如果我们的vuex需要先通过一些异步的操作再修改状态
      // 就使用 this.$store.dispatch来触发 actions当中的函数
      // 然后 actions当中的函数再commit('')提交，使用mutations来修改状态
      this.$store.dispatch('changeTotalAsync')
    },
    fn3(){
      // commit不仅仅会触发根实例上的mutation 也会触发modules当中的mutation
      this.$store.commit('fncom')
    },
    fn4(){
      // 如果模块开启了命名空间 
      // 我们就可以指定命名空间加上函数名称的方式来精准的触发
      // 对应模块当中的指定的mutations
      this.$store.commit('order/fncom')
    },
    // 方便我们把mutation当中的函数映射出来成为组件内的方法 ，可以直接调用
    ...mapMutations(['fncom'])
  },
  computed:{
    ...mapState(['total'])
  },
  beforeRouteLeave(to,from){
    console.log('即将离开首页')
    // 一般我们可以使用这个离开前的路由 提醒用户完成了一些数据保存的工作后确认无误后跳转
      return true
  }


}
</script>
