<template>
  <div class="about">
    <h1>This is an about page</h1>
    <div>  {{  $store.state  }}</div>
    <router-link to="/list?kkk=5555" replace> 替换到 list</router-link>
    <button @click="gotoList"> 跳转到list</button>
  </div>
</template>

<script setup>
import { useStore } from 'vuex';
import { useRouter , useRoute}  from 'vue-router'
import {  onMounted } from 'vue'

const store = useStore();
console.log('store in about', store)

const router = useRouter(); // this.$router
const route = useRoute();   // this.$route
const gotoList = ()=>{
    router.replace('/list')
}

onMounted(()=>{
  console.log('route in about', route.query)
})

</script>

