import { createRouter, createWebHashHistory } from 'vue-router'
import HomeView from '../views/HomeView.vue'

// 1  路由如何配置
// 2  如何跳转
// 3  参数传递

const routes = [
  {
    path: '/',
    name: 'home',
    component: HomeView
  },
  {
    path: '/about',
    name: 'about',
    // 使用函数 返回一个import的组件的写法是配合打包工具
    // 对于当前的文件进行按需加载处理，单独的打包成一个独立的bundle文件
    //  一般除了一开始就需要展示的页面以外都采用这种方式，可以提升首屏的加载速度
    //  是vue的常规的性能优化的方式之一  ( React.lazy )
    component: () => import( '../views/AboutView.vue')
  },
  {
    path: '/list',
    name: 'list',
    component: ()=>import('../views/List.vue')
  },
  {
    // 必须在路由的路径上 对于abc参数进行声明
    path:'/detail/:abc',
    name: 'detail',
    component: ()=>import('../views/Detail.vue'),
    kkk:456,
   
    meta:{
      kkk: 8888,
      title:'我是详情页'
    } 
  }
]

const router = createRouter({
  history: createWebHashHistory(),
  routes
})

// 发生在跳转之前  每一个路由跳转之前
//  新写法
// router.beforeEach((to,from)=>{
//   // to 要前往的路由信息
//   // from 跳转前的路由信息
//   // 简单守卫 通过返回布尔值来确定是否可以跳转
//   // if(to.path === '/about') return false
//   // return true 

//   //  return 一个To对象来切换跳转的目的
//   if(to.path === '/about') return  {  path:'/list' }
//   return true

// })

// 全局路由守卫

// 为了兼容上个版本的路由  保留了路由守卫的第三个 next参数的使用
router.beforeEach((to,from,next)=>{
  // to 要前往的路由信息
  // from 跳转前的路由信息
  // 简单守卫 通过返回布尔值来确定是否可以跳转
  // if(to.path === '/about') return false
  // return true 

  //  return 一个To对象来切换跳转的目的
  if(to.path === '/about') return next({  path:'/list' })
  next(); //正常的跳转到下一个路由

})

router.afterEach((to,from)=>{
  // 进行一下数据埋点的操作 用来统计用户访问行为等的目的
})
export default router
