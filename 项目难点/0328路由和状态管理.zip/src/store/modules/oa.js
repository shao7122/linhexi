export default {
    state:{
     sitename:'我是oa模块',
     total:100,
    },
    getters:{},
    mutations:{
     fncom(){
       console.log('我是oa模块当中的fncom')
     }
    },
    actions:{},
    modules:{}
}