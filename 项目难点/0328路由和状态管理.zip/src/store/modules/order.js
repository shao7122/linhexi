export default {
    namespaced: true, // 默认值是false true标识开启命名空间
    mutations:{
      fncom(){
        console.log('我是 order 模块当中的fncom')
      }
    }
}
