import { createStore } from 'vuex'
import oa from './modules/oa'
import order from './modules/order'
export default createStore({
  state: {  //全局共享状态
    total:100,
    userInfo:{
      name:'dixon',
      age:17
    }
  },
  getters: { // 取值器  vuex提供的一个 计算属性  里面的值是已经一个函数返回的
    dbTotal(state){
      // 第一个参数就是 store实例的state属性
      return state.total * 2
    }
  },
  // mutations 翻译为 改变 变更
  mutations: {
    setTotal(state,payload){
      state.total += payload;
    },
    fncom(){
      console.log('我是根实例当中的fncom')
    }
  },
  actions: {
    // 通过代码可以发现 上面的mutaion是同步的修改了状态 
    // 但是vuex还是提供了一个配置让我们可以先去执行一些异步的操作然后再修改状态
    changeTotalAsync(ctx,payload){
      // ctx 就是当前的store实例自身
       setTimeout(()=>{
        ctx.commit('setTotal', 5)
       },1000)
    } 
  },
  // modules 模块的意思
  // 如果我们的项目足够大 我们需要对于状态进行进一步的划分归类
  // 就可以使用modules
  modules: {
     oa,
     order
  }
})

