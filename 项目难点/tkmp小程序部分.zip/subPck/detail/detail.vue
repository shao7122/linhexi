<template>
	<view>
	  <h1>{{ content.title }}</h1>
	  <div> 添加时间 {{ content.updatedAt }} </div>
	  <cx-audio-play
	    v-if="content.audio"
	   :list="[content.audio]"
	   :autoplays="true"
	  ></cx-audio-play>
	  <div>
		  <rich-text :nodes="content.desc"></rich-text>
			
	  </div>
			
	</view>
</template>

<script>
	import { getQuestionDetail } from '@/api/question.js'
	export default {
		data() {
			return {
				
				content:{}
			}
		},
		onLoad(query){
			this.id = query.id
			this.getDetail(query.id)	
		},
		created(){
			this.getDetail(this.id)	
		},
		methods: {
			async getDetail(id){
				const res = await getQuestionDetail(id)
				this.content = res.data;
				// 动态的设置导航栏标题
				wx.setNavigationBarTitle({title:this.content.title})
			}
		}
	}
</script>

<style>

</style>
