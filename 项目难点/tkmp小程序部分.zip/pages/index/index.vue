<template>
	<div> 
		题库列表
		<ul>
			<li class="item" v-for="item of list" :key="item.id" @click="go(item.id)">
				<span>{{ item.title }}</span>	
				<span> {{ item.type | typeTxt }} </span>
			</li>
		</ul>
	</div>
</template>
<script>
	
	import { getQuestion } from '@/api/question.js'
	export default {
		data(){
			return {
				list:[],
				page:1,
				limit:15,
				total: 1000,
			}
		},
		created(){
			this.getList()
		},
		// 这个钩子是在 开启了 enablePullDownRefresh 才有的
			
		onPullDownRefresh(){
			console.log('下拉刷新')
			this.list =[]
			this.page = 1;
			this.getList().then(()=>{
				// 加载完成之后 记得关闭刷新
				setTimeOut(()=>{
					wx.stopPullDownRefresh()
				},1000)
				
			});
		},
		// 在页面触及底部的时候
		onReachBottom(){
			if(this.list.length >=this.total){
				return this.$toast('没有更多的数据了')
			}
			this.page++;
			this.getList();
		},
		methods:{
			//  跳转到详情页
			go(id){
				uni.navigateTo({
					url:'/subPck/detail/detail?id='+id
				})
			},
			async getList(){
				if(this.list.length >=this.total){
					return this.$toast('没有更多的数据了')
				}
				
				 const params = {
				      $limit: this.limit,
				      $skip: (this.page - 1) * this.limit,
					 '$sort[id]': -1,
				    };

				const res  =await getQuestion(params)
				this.list = [...this.list,...res.data.data]
				this.total = res.data.total
			}
		},
		filters:{
			typeTxt(val){
				if(val == 1 ) return '笔试真题' 
				if(val == 2 ) return '录音' 
				if(val == 3 ) return '常规题' 
			}
		}
	}
</script>

<style scoped lang="scss">
	.item{
		padding:10px;
		line-height: 30px;
		border-bottom: 1px solid #ccc;
		display: flex;
		justify-content: space-between;
	}
	
</style>
	