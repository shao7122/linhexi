import $api from './index.js';


// 添加公司
export function addQuestion(data) {
  return $api.post('/question', data);
}

export function getQuestionDetail(id){
	 return $api.get('/question/'+id );
}


export function getQuestion(params) {
  return $api.get('/question', params );
}

// 根据id 

export function delQuestion(id) {
  return $api.delete(`/question/${id}`);
}
