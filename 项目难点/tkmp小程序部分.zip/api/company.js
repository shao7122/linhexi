import $api from './index.js';


// 添加公司
export function addCompany(data) {
  return $api.post('/company', data);
}



export function getCompany(params) {
  return $api.get('/company', { params });
}

// 根据id 删除公司

export function delCompany(id) {
  return $api.delete(`/company/${id}`);
}
