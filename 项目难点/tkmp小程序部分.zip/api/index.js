
	

	const baseURL = 'http://127.0.0.1:3030';
	
	
	const $api = {};
	
	$api.post = (url,data)=>{
		const token = wx.getStorageSync('token');
		return new Promise((resolve,reject)=>{
				uni.request({
					url: baseURL+url,
					method:'POST',
					data,
					header:{
							Authorization: 'Bearer '+token
					},
					success(res){
						resolve({ status: res.status, data:res.data })
					}
				})
		})
	}
	
	$api.get = (url,data)=>{
		const token = wx.getStorageSync('token')
		return new Promise((resolve,reject)=>{
				uni.request({
					url: baseURL+url,
					method:'GET',
					header:{
							Authorization: 'Bearer '+token
					},
					data,
					success(res){
						resolve({ status: res.status, data:res.data })
					}
				})
		})
	}


export default $api;