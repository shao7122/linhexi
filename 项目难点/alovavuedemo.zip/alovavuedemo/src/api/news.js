import alovaIns from '@/api/index'

export const getList =  alovaIns.Get('/topics',{
    // 对于请求的返回的响应的数据进行处理
    async transformData(rawData){
        return  await rawData.json()
      }
})

