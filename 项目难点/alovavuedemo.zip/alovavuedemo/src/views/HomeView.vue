<template>
  <div class="home">
        <button @click="fn1">获取列表</button>
        
        <div v-if="loading"> 数据获取中 请耐心等待 </div>
        <ul>
          <li v-for=" item of data.data" :key="item.id">
            {{  item.title }}
          </li>
        </ul>
        
  </div>
</template>
<script setup>

import { getList } from '@/api/news'
import { useRequest } from 'alova';

let { 
  loading,
  data,
  error,
} = useRequest(getList)






</script>
