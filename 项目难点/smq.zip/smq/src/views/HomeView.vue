<template>
  <div class="home">
        我是一个首页
  </div>
</template>

<script>
import { throwStatement } from '@babel/types';


export default {
  name: 'HomeView',


}
</script>
