<template>

  <div>
    <router-view/>
    <Good />
  </div>
  
</template>

<script setup>
import  Good from './components/Good.vue'

</script>

