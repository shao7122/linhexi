const { app, BrowserWindow,ipcMain , contextBridge, ipcRenderer, Menu } = require('electron')
const path = require('path');

const createWindow = () => {
    //  创建一个窗口
    const win = new BrowserWindow({
      width: 1000,
      height: 800,
      fullscreen: false,  // 设置是否全屏
      movable: true, // 是否可以拖动
      webPreferences:{
        devTools: true,
        preload: path.join(__dirname, 'preload.js')  // 在渲染之前预加载一个js文件
      }
    })
  
    // 在这个窗口加载指定的文件
    win.loadFile('./src/vueproject/index.html')
    // win.loadURL('http://localhost:8080')

    // 打开调试工具
    win.webContents.openDevTools()
   


    // 普通的子窗口
    // 普通窗口之下  父子窗口都可以进行独立的操作
    const childWin = new BrowserWindow({
      parent: win
    })

    childWin.loadURL('http://www.qq.com')


    // modal形式的子窗口
    //  modal的情况下子窗口的出现好影响父窗口内容的操作 聚焦在子窗口

    // const modalWin = new BrowserWindow({
    //   parent: win,
    //   modal: true
    // })
    // modalWin.loadURL('http://www.qq.com')

    // setTimeout(()=>{
    //   win.close()
    // },5000)


    //  主线程的监听 监听由vue发送过来的事件
    // 监听使用 ipcRenderer的send发送过来的事件  
    ipcMain.on('closeChild',(event,res)=>{
      // 第一个参数是event对象
      // 第二个是send的时候传递的参数
      console.log('res',res)
      childWin.hide();
    })

    ipcMain.on('openChild',()=>{
      childWin.show()
    })


    //设置系统菜单

    const template = [ // 菜单的配置
      { 
          label: '菜单1',
          submenu:[
              { 
                  label:'子菜单1',
                  accelerator:'ctrl+n' // 给这个菜单添加一个快捷键
              },
              {  label:'子菜单2'},
              {  label:'子菜单3'},
              {  label:'子菜单4'},

          ]
      },
      { 
          label: '菜单2',
          submenu:[
              { 
                  label:'打开oa模块',
                  click(){
                    const newchild = new BrowserWindow({
                      parent: win
                    })
                    newchild.loadFile('./src/vueproject/index.html',{
                      hash:'about'
                    })


                  }
              },
              {  label:'子菜单2-2'},
              {
                label:'打开腾讯',
                click(){
                  const newchild = new BrowserWindow({
                    parent: win
                  })
                  newchild.loadURL('http://www.qq.com')
                }
              }

          ]
      }
    ]

    const myMenu = Menu.buildFromTemplate(template); // 生成一个菜单
    Menu.setApplicationMenu(myMenu);  // 设置菜单



  }


  app.whenReady().then(() => {
    createWindow()
  })