const {  contextBridge,ipcRenderer } = require('electron');

// 在这个位置暴露一些方法给到 渲染进程(网页)
 contextBridge.exposeInMainWorld(
        'electron',
        {
            /// ipcRenderer.send() 发送消息给主线程 
          closeChild: () => ipcRenderer.send('closeChild',123456),
          openChild: ()=>ipcRenderer.send('openChild')
        }
 )