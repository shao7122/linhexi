import { createStore } from 'vuex'

export default createStore({
  state: {
    curCpPops:{}
  },
  getters: {
  },
  mutations: {
    setCurCp(state,payload){
      state.curCpPops = payload
    }
  },
  actions: {
  },
  modules: {
  }
})
