<template>
  <div class="box">
    <!-- 物料区 -->
    <div class="left">
        <div class="mtbox" @drag="whichCpIsDrag=item.cpname" draggable="true" v-for="item of Mts">
          {{ item.cname}}
        </div>
    </div>
    <div class="mid">
      <!-- 预览区 -->
      <div class="platform" @drop="handleDrop" @dragover="handleOver">
        <draggable 
            v-model="cplist" 
            group="people" 
            @start="drag=true" 
            @end="drag=false" 
            item-key="cpname">
            <template #item="{element}">
                  <Cp1 @select="handleSelect" :pops="{...element.properties,id: element.id}" />
            </template>
          </draggable>
      
      </div>
    </div>
    <!-- 属性设置区域 -->
    <div class="right">

        <!-- 针对不同的组件  去自定义他们不同的属性 -->
        <template v-if="curCp.type=='input' ">
            <div> 设置输入框的文本提示 <input v-model="curCp.placeholder" /> </div>
        </template>
        <template v-if="curCp.type=='select' ">
            <div>
              <div>配置下拉框可以选择的内容</div>
              <div v-for="(item,index) of curCp.enum"> 
                <input  v-model="curCp.enum[index]" />  <span @click="curCp.enum.splice(index,1)">删除</span>
              </div>
              <button @click="curCp.enum.push('')">添加</button>
            </div> 

        </template>

    </div>

  </div>
</template>

<script>
import Cp1 from '@/components/Cp1.vue'
import Cp2 from '@/components/Cp2.vue'
// 导入物料
import Mts from '@/mats/index'

export default {
  components:{
    Cp1,
    Cp2,
  },
  data() {
    return {

        cplist:[],
        Mts,
        whichCpIsDrag:'' ,// 当前正在拖拽的组件名称
        curCp: {}
   
    }
  },
  methods:{
    handleDrop(ev){
      if(!this.whichCpIsDrag) return false;
      console.log(this.whichCpIsDrag,'这个组件拖拽到预览区了' )
      // this.inUse.push(this.whichCpIsDrag)
      const curCp = this.Mts.find(item=>item.cpname === this.whichCpIsDrag);
      this.whichCpIsDrag = ''
      this.cplist.push({...curCp,id: Date.now()})
    },  
    //阻止冒泡
    handleOver(ev){
      ev.preventDefault()
    },
    handleSelect(id){
        console.log('选中的组件的id',id)
        this.curCp = this.cplist.find(item=>item.id===id).properties
    }
  }

}
</script>


<style>
.platform{
  width: 375px;
  height: 700px;
  border:1px solid #ccc;
  box-shadow: 3px 3px 3px rgba(0,0,0,.3);
}
.box{
  display: flex;
  width: 100vw;
  height: 100vh;
}
.left{
  width: 300px;
  border-right: 1px solid red;
}
.mtbox{
  width: 100px;
  height: 100px;
  border-bottom: 1px solid #ccc;
  box-sizing: border-box;
  float:left;
  border-right: 1px solid #ccc;
  display: flex;
  align-items: center;
  justify-content: center;
}
.mtbox:nth-child(3n){
  border-right:none
}
.mid{
 flex:1;
 display: flex;
 justify-content: center;
 align-items: center;
}
.right{
  width: 300px;
  border-left: 1px solid red;
}
</style>