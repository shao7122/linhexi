<template>
    <div>
        <div> {{  pops.title }} </div>
      <template v-if="pops.type === 'select'">
           <select v-model="pops.value">
             <option v-for="item of pops.enum">
                    {{ item }}
            </option>
           </select>
      </template>
    </div>
</template>
<script>
    export default {
        props:['pops']
    }
</script>