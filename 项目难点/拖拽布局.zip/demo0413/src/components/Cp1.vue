<template>
    <div class="got" ref="got" @click="fn1">
        <div> {{  pops.title }} </div>
      <template v-if="pops.type === 'input'">
            <input v-model="pops.value" :placeholder="pops.placeholder" />
      </template>
        <template v-if="pops.type === 'select'">
            <select v-model="pops.value">
                <option v-for="item of pops.enum">
                        {{ item }}
                </option>
            </select>
        </template>
        <template  v-if="pops.type === 'lbt'">
            <el-carousel height="150px">
                <el-carousel-item v-for="item in pops.urls" :key="item">
                    <h3 class="small justify-center" text="2xl">{{ item }}</h3>
                </el-carousel-item>
             </el-carousel>
        
       </template>
    </div>
</template>
<script>
    export default {
        props:['pops'],
        mounted(){
            //  console.log('this.pops',this.pops)
        },
        methods:{
            fn1(ev){
                for(const it of document.querySelectorAll('.got')){
                    it.classList.remove('ac')
                }
                this.$refs.got.classList.add('ac')

                // this.$store.commit('setCurCp', this.pops)
                this.$emit('select', this.pops.id)
            }
        }
    }
</script>
<style>
.ac{
    border: 3px solid red;
}
    .got:active {

        border: 3px solid red;
     }
</style>